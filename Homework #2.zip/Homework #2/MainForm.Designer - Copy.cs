﻿namespace GuessTheNumber
{
    partial class MainForm
    {

        private System.ComponentModel.IContainer components = null;

      
        /// <param name="disposing"
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInstruction = new System.Windows.Forms.Label();
            this.lblHint = new System.Windows.Forms.Label();
            this.txtGuess = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Location = new System.Drawing.Point(208, 237);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(318, 16);
            this.lblInstruction.TabIndex = 2;
            this.lblInstruction.Text = "I have a number between 1 and 1000--can you guess";
            this.lblInstruction.Click += new System.EventHandler(this.lblInstruction_Click_1);
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Location = new System.Drawing.Point(208, 266);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(44, 16);
            this.lblHint.TabIndex = 3;
            this.lblHint.Text = "label2";
            // 
            // txtGuess
            // 
            this.txtGuess.Location = new System.Drawing.Point(211, 373);
            this.txtGuess.Name = "txtGuess";
            this.txtGuess.Size = new System.Drawing.Size(455, 22);
            this.txtGuess.TabIndex = 4;
            this.txtGuess.TextChanged += new System.EventHandler(this.txtGuess_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(357, 431);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(480, 431);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "New Game";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(900, 661);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtGuess);
            this.Controls.Add(this.lblHint);
            this.Controls.Add(this.lblInstruction);
            this.Name = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.TextBox txtGuess;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}

