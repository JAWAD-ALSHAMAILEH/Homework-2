﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GuessTheNumber
{
    public partial class MainForm : Form
    {
        private int numberToGuess;        
        private int previousDifference;  

        public MainForm()
        {
            InitializeComponent();
            StartNewGame(); 
        }

        private void StartNewGame()
        {
            Random random = new Random();
            numberToGuess = random.Next(1, 1001); 
            previousDifference = int.MaxValue;   
            lblInstruction.Text = "I have a number between 1 and 1000--can you guess my number? Please enter your first guess.";
            lblHint.Text = "";                  
            txtGuess.Enabled = true;            
            txtGuess.Text = "";                 
            this.BackColor = DefaultBackColor;  
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtGuess.Text, out int userGuess)) 
            {
                int currentDifference = Math.Abs(numberToGuess - userGuess); 

                if (userGuess == numberToGuess) 
                {
                    MessageBox.Show("Correct!", "Congratulations"); 
                    this.BackColor = Color.Green;                  
                    txtGuess.Enabled = false;                     
                }
                else
                {
                    lblHint.Text = userGuess < numberToGuess ? "Too Low" : "Too High";

                    if (currentDifference < previousDifference)
                    {
                        this.BackColor = Color.Red; 
                    }
                    else
                    {
                        this.BackColor = Color.Blue; 
                    }

                    previousDifference = currentDifference; 
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number!", "Error"); 
        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            StartNewGame(); 
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
           
        {
            if (int.TryParse(txtGuess.Text, out int userGuess))
            {
                int currentDifference = Math.Abs(numberToGuess - userGuess);

                if (userGuess == numberToGuess)
                {
                    MessageBox.Show("Correct!", "Congratulations");
                    this.BackColor = Color.Green;
                    txtGuess.Enabled = false;
                }
                else
                {
                    lblHint.Text = userGuess < numberToGuess ? "Too Low" : "Too High";

                    if (currentDifference < previousDifference)
                    {
                        this.BackColor = Color.Red;
                    }
                    else
                    {
                        this.BackColor = Color.Blue;
                    }

                    previousDifference = currentDifference;
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number!", "Error");
            }
        }

        }

        private void lblInstruction_Click(object sender, EventArgs e)
        {

        }

        private void lblHint_Click(object sender, EventArgs e)
        {

        }

        private void btnNewGame_Click_1(object sender, EventArgs e)
        {

        }

        private void txtGuess_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        {
            if (int.TryParse(txtGuess.Text, out int userGuess))
            {
                int currentDifference = Math.Abs(numberToGuess - userGuess);

                if (userGuess == numberToGuess)
                {
                    MessageBox.Show("Correct!", "Congratulations");
                    this.BackColor = Color.Green;
                    txtGuess.Enabled = false;
                }
                else
                {
                    lblHint.Text = userGuess < numberToGuess ? "Too Low" : "Too High";

                    if (currentDifference < previousDifference)
                    {
                        this.BackColor = Color.Red;
                    }
                    else
                    {
                        this.BackColor = Color.Blue;
                    }

                    previousDifference = currentDifference;
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number!", "Error");
            }
        }

    }

        private void button2_Click(object sender, EventArgs e)
        {
           

        {
            StartNewGame();
        }

    }

        private void lblInstruction_Click_1(object sender, EventArgs e)
        {

        }
    }
}

